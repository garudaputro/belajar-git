// preloader
$(window).on('load', function () {
    $('.loader-bg').hide();
});
AOS.init({
    duration: 1000,
    once: true,
});
// var tl = gsap.timeline({
//     defaults: {
//         duration: 1,
//         opacity: 0

//     }
// });
// tl.from(".stagger1", {
//     y: 100,
//     duration: 1,
//     stagger: .2,
//     ease: none,
//     opacity: 0
// })

$(document).ready(function () {
    $(".slideshow-banner").owlCarousel({
        loop: true,
        margin: 10,

        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            }
        }
    });

    $(".slideshow-catagories").owlCarousel({
        margin: 10,
        dots: false,
        responsive: {
            0: {
                items: 4
            }
        }
    });

    $(".image-product-details-slideshow").owlCarousel({
        loop: true,
        margin: 10,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            900: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    });
    $(".testimonial-slideshow").owlCarousel({
        loop: true,
        margin: 10,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            900: {
                items: 1
            },
            1000: {
                items: 2
            }
        }
    });



});



// tl.from(".hero-section", {
//     y: 50,

// })



// youtube popup
// $(function () {
//     $('.popup-youtube, .popup-vimeo').magnificPopup({
//         disableOn: 700,
//         type: 'iframe',
//         mainClass: 'mfp-fade',
//         removalDelay: 160,
//         preloader: false,
//         fixedContentPos: false
//     });
// });


$(document).ready(function () {
    $('.list').click(function () {
        const value = $(this).attr('data-filter');
        if (value == 'all') {
            $('.item-box').show('1000');
        } else {
            $('.item-box').not('.' + value).hide('1000');
            $('.item-box').filter('.' + value).show('1000');
        }
    })

    // add class active on clicked
    $('.list').click(function () {
        $(this).addClass('active').siblings().removeClass('active')
    })
})